J. ARSHINI REDDY — DIGITAL MARKETING PORTFOLIO

Files:
- index.html: responsive portfolio website
- arshini-profile.jpg: profile photo used by the website

Before publishing:
1. Open index.html in a browser to preview.
2. Add your LinkedIn profile URL and resume link in index.html.
3. Review all details and contact information.
4. Sample marketing campaigns are fictional practice concepts, not client work or measured results.

Publish free with GitHub Pages:
1. Sign in/create account at https://github.com/
2. Create a public repository, e.g. arshini-portfolio.
3. Upload BOTH index.html and arshini-profile.jpg to the repository root.
4. Go to Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
5. Wait for the published URL to appear in Settings -> Pages.
